create definer = root@localhost view v_emp as
select `scott`.`emp`.`ENAME` AS `ename`, `scott`.`emp`.`EMPNO` AS `empno`, `scott`.`emp`.`JOB` AS `job`
from `scott`.`emp`
where (`scott`.`emp`.`DEPTNO` = 30);

