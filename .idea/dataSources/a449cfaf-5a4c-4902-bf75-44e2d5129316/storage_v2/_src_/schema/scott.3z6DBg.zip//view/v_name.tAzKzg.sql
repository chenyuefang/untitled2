create definer = root@localhost view v_name as
select `e`.`EMPNO` AS `EMPNO`, `e`.`ENAME` AS `ENAME`, `d`.`DNAME` AS `DNAME`
from (`scott`.`emp` `e`
       join `scott`.`dept` `d` on ((`e`.`DEPTNO` = `d`.`DEPTNO`)));

